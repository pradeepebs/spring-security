package design_pattern;

public class testing_singelton {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		singleton s1=singleton.getInstance();
		singleton s2=singleton.getInstance();

		if(s1==s2) {
			System.out.println("same");
		}
		else {
			System.out.println("differnet");
		}
	}

}
