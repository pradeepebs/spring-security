package design_pattern;

/*sinleton design pattern
 * Eager loading
 * 1.make default constructor as oprivate
 * 2.create private static class type variable
 * 3.initl obj in constructor
 * 4.create public sttaitc get objkect/get instance and return class object
 * */
public class singleton {
//	
//	private static singleton obj=null;
//	private singleton() {}
//	public static singleton getInstance() {
//		return obj;
	//}
	private static singleton obj=null;
	private singleton() {}
	public static singleton getInstance() {
		if(obj==null)
			obj=new singleton();
		return obj;
	}
}
